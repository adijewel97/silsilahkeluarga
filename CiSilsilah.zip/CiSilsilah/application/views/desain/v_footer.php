        <!-- footer content -->
        <footer>
          <div class="pull-right" style=" font-size:9px">
           <!-- Copy@052017 by Mamang -->
            By Mamang Copy@05-2017
          </div>
          <div class="clearfix"></div>
        </footer>
        <!-- /footer content -->
      </div>
    </div>
 

    <!-- jQuery -->
    <!-- <script type="text/javascript" src="<?php echo base_url('assets/jquery/dist/jquery.min.js'); ?>"></script> -->
    <!-- Bootstrap -->
    <script type="text/javascript" src="<?php echo base_url('assets/bootstrap/dist/js/bootstrap.min.js'); ?>"></script>
    <!-- FastClick -->
    <script type="text/javascript" src="<?php echo base_url('assets/fastclick/lib/fastclick.js'); ?>"></script>
    <!-- NProgress -->
    <script type="text/javascript" src="<?php echo base_url('assets/nprogress/nprogress.js'); ?>"></script>
    <!-- Chart.js -->
    <script type="text/javascript" src="<?php echo base_url('assets/Chart.js/dist/Chart.min.js'); ?>"></script>
    <!-- gauge.js -->
    <script type="text/javascript" src="<?php echo base_url('assets/gauge.js/dist/gauge.min.js'); ?>"></script>
    <!-- bootstrap-progressbar -->
    <script type="text/javascript" src="<?php echo base_url('assets/bootstrap-progressbar/bootstrap-progressbar.min.js'); ?>"></script>
    <!-- iCheck -->
    <script type="text/javascript" src="<?php echo base_url('assets/iCheck/icheck.min.js'); ?>"></script>
    <!-- Skycons -->
    <script type="text/javascript" src="<?php echo base_url('assets/skycons/skycons.js'); ?>"></script>
    <!-- Flot -->
    <script type="text/javascript" src="<?php echo base_url('assets/Flot/jquery.flot.js'); ?>"></script>
    <script type="text/javascript" src="<?php echo base_url('assets/Flot/jquery.flot.pie.js'); ?>"></script>
    <script type="text/javascript" src="<?php echo base_url('assets/Flot/jquery.flot.time.js'); ?>"></script>
    <script type="text/javascript" src="<?php echo base_url('assets/Flot/jquery.flot.stack.js'); ?>"></script>
    <script type="text/javascript" src="<?php echo base_url('assets/Flot/jquery.flot.resize.js'); ?>"></script>
    <!-- Flot plugins -->
    <script type="text/javascript" src="<?php echo base_url('assets/flot.orderbars/js/jquery.flot.orderBars.js'); ?>"></script>
    <script type="text/javascript" src="<?php echo base_url('assets/flot-spline/js/jquery.flot.spline.min.js'); ?>"></script>
    <script type="text/javascript" src="<?php echo base_url('assets/flot.curvedlines/curvedLines.js'); ?>"></script>
    <!-- DateJS -->
    <script type="text/javascript" src="<?php echo base_url('assets/DateJS/build/date.js'); ?>"></script>
    <!-- JQVMap -->
    <script type="text/javascript" src="<?php echo base_url('assets/jqvmap/dist/jquery.vmap.js'); ?>"></script>
    <script type="text/javascript" src="<?php echo base_url('assets/jqvmap/dist/maps/jquery.vmap.world.js'); ?>"></script>
    <script type="text/javascript" src="<?php echo base_url('assets/jqvmap/examples/js/jquery.vmap.sampledata.js'); ?>"></script>
    
    <script type="text/javascript" src="<?php echo base_url('assets/build/js/custom.min.js'); ?>"></script>
  
 </body>
</html>