  <div class="col-sm-9 mail_view">
      <div class="inbox-body">
        <div class="mail_heading row">
          <div class="col-md-12">
            <h4> Donec vitae leo at sem lobortis porttitor eu consequat risus. Mauris sed congue orci. Donec ultrices faucibus rutrum.</h4>
          </div>
        </div>
        <div class="view-mail">
            <div class="x_content">
              <div class="col-md-7 col-sm-7 col-xs-12">
                <div class="product-image">
                  <img src="<?php echo base_url('arsip/images/event/2017-06-01 1/mancing Keluarga.jpg'); ?>" alt="..." />
                </div>
                <div class="product_gallery">
                  <a>
                    <img src="<?php echo base_url('arsip/images/event/2017-06-01 1/mancing2.jpg'); ?>"  alt="..." style="width: 98px; height: 74px"/>
                  </a>
                  <a>
                    <img src="<?php echo base_url('arsip/images/event/2017-06-01 1/mancing3.jpg'); ?>"  alt="..."  style="width: 98px; height: 74px"/>
                  </a>
                  <a>
                    <img src="<?php echo base_url('arsip/images/event/2017-06-01 1/mancing4.jpg'); ?>"  alt="..." style="width: 98px; height: 74px"/>
                  </a>
                  <a>
                    <img src="<?php echo base_url('arsip/images/event/2017-06-01 1/mancing5.jpg'); ?>"  alt="..." style="width: 98px; height: 74px"/>
                  </a>
                </div>
              </div>
              
              <div class="col-md-5 col-sm-5 col-xs-12" style="border:0px solid #e5e5e5;">
    
                <h3 class="prod_title">Ulasan Event Keluarga</h3>
                <br/>
    
                <h4><i class="fa fa-bug"> </i> Mancing Keluarga di Patimban Subang</h4>
    
                <p><p>Patimban – Proyek pelabuhan Patimban kini menjadi lokasi favorit para pehobi mancing di Pantura Subang. 
                   Lokasi ini juga cocok sambil bawa keluarga dan botram, disarankan membawa kendaraan roda 4 sebagi 
                   pelindung dari terik Matahari.</p>
                <br />
                </p>
    
                 <div class="">
                  <h4><i class="fa fa-bug"> </i> Lokasi Event </h4>
                   <p> 06 Mei 2017</p>
                </div>
                <br />
    
                <div class="">
                  <h4><i class="fa fa-bug"> </i> Tanggal Event </h4>
                   <p> 06 Mei 2017</p>
                <br />
                </div>
    
                <div class="">
                  <h2><i class="fa fa-bug"> </i> Peserta  <small>Please select one</small></h2>
                   <p> Udin,Ujang, keluarga mang Yeye</p>
                   <p> </p>
                </div>
                <br />
            </div>                              
        </div>
    
        <!-- end of user messages -->
        <ul class="messages">
          <li>
            <img src="<?php echo base_url('arsip/images/users/'.$userid.'.jpg') ?>" class="avatar" alt="Avatar">
            <div class="message_date">
              <h5 class="date text-info">24</h5>
              <p class="month">May</p>
            </div>
            <div class="message_wrapper">
              <h4 class="heading">Desmond Davison</h4>
               <span>Raw denim you probably haven't heard of them jean shorts Austin. Nesciunt tofu stumptown aliqua butcher retro keffiyeh dreamcatcher synth.</span>
              <br />
             </div>
          </li>
          <li>
            <img src="<?php echo base_url('arsip/images/users/'.$userid.'.jpg') ?>" class="avatar" alt="Avatar">
            <div class="message_date">
              <h5 class="date text-info">24</h5>
              <p class="month">May</p>
            </div>
            <div class="message_wrapper">
              <h4 class="heading">Desmond Davison</h4>
               <span>Raw denim you probably haven't heard of them jean shorts Austin. Nesciunt tofu stumptown aliqua butcher retro keffiyeh dreamcatcher synth.</span>
              <br />
             </div>
          </li>
          <li>
            <img src="<?php echo base_url('arsip/images/users/'.$userid.'.jpg') ?>" class="avatar" alt="Avatar">
            <div class="message_date">
              <h5 class="date text-info">24</h5>
              <p class="month">May</p>
            </div>
            <div class="message_wrapper">
              <h4 class="heading">Desmond Davison</h4>
               <span>Raw denim you probably haven't heard of them jean shorts Austin. Nesciunt tofu stumptown aliqua butcher retro keffiyeh dreamcatcher synth.</span>
              <br />
             </div>
          </li>
        </ul>
        <!-- end of user messages -->
    
        <div class="col-md-10">
            <textarea rows = "4" class="resizable_textarea form-control" placeholder="Send Command"></textarea>
        </div>
        <div class="col-md-2">
          <span class="input-group-btn">
            <button type="button" class="btn btn-primary">Send</button>
          </span>
        </div>
      </div>
  </div>