<?php 
    $user_kdunit    = $this->session->userdata('user_kdunit');
    $user_id        = $this->session->userdata('user_id'); 
    $user_group     = $this->session->userdata('user_group');
    $user_password  = $this->session->userdata('user_password');
    $user_name      = $this->session->userdata('user_name');
    $user_expire    = $this->session->userdata('user_expire');
    $userid         = $user_id;
 
?>
<style type="text/css">
    .about {
        margin-top: 20%; 
        margin-bottom: 10%;
    }  
</style>

 <!-- page content -->
    
    <div class="right_col" role="main">
        <div class=""> 

            <div>
              <div class="login_wrapper about">
                <div id = "login_form" class="animate form">
                    <section class="login_content">
                        <div class="col-md-12 col-sm-12 col-xs-12">
                            <div class="x_panel">
                              <div class="x_content">
                                <p class=MsoNormal align=center style='text-align:center'><b style='mso-bidi-font-weight:
                                normal'><span style='color:#002060'>
                                    <a href="<?php echo base_url() ?>utility/Help-Aplikasi_Silislah_Keluarga.pdf"> Aplikasi Silsilah/Keturunan Keluarga</a>
                                    <o:p></o:p></span></b></p>
                        
                                <p class=MsoNormal align=center style='margin-bottom:0cm;margin-bottom:.0001pt;
                                text-align:center'><span style='font-size:8.0pt;mso-bidi-font-size:11.0pt;
                                line-height:115%'><o:p>&nbsp;</o:p></span></p>
                        
                                <p class=MsoNormal align=center style='margin-bottom:0cm;margin-bottom:.0001pt;
                                text-align:center'><b style='mso-bidi-font-weight:normal'><span
                                style='font-size:8.0pt;mso-bidi-font-size:11.0pt;line-height:115%'>Ver.<span
                                style='mso-spacerun:yes'>  </span>1.00.01<o:p></o:p></span></b></p>
                        
                                <p class=MsoNormal align=center style='margin-bottom:0cm;margin-bottom:.0001pt;
                                text-align:center'><b style='mso-bidi-font-weight:normal'><span
                                style='font-size:7.0pt;mso-bidi-font-size:11.0pt;line-height:115%'><o:p>&nbsp;</o:p></span></b></p>
                        
                                <p class=MsoNormal align=center style='margin-bottom:0cm;margin-bottom:.0001pt;
                                text-align:center'><span style='font-size:7.0pt;mso-bidi-font-size:11.0pt;
                                line-height:115%'><o:p>&nbsp;</o:p></span></p>
                        
                                <p class=MsoNormal align=center style='margin-bottom:0cm;margin-bottom:.0001pt;
                                text-align:center'><span style='font-size:8.0pt;mso-bidi-font-size:11.0pt;
                                line-height:115%'>Create By <a href="mailto:adijewel97@yahoo.com">adijewel97@yahoo.com</a><o:p></o:p></span></p>
                        
                                <p class=MsoNormal align=center style='margin-bottom:0cm;margin-bottom:.0001pt;
                                text-align:center'><span style='font-size:7.0pt;mso-bidi-font-size:11.0pt;
                                line-height:115%;mso-bidi-font-family:Calibri;mso-bidi-theme-font:minor-latin'>©</span><span
                                style='font-size:7.0pt;mso-bidi-font-size:11.0pt;line-height:115%'>2017<o:p></o:p></span></p>
                              </div>
                            </div>
                        </div>
                    </section>
                </div>
              </div>
            </div>

        </div>
    </div>    
<!-- /page content -->

